import { useState } from 'react';

// أنواع البيانات
interface Project {
  id: number;
  title: string;
  description: string;
  image: string;
  tags: string[];
  link?: string;
  category: string;
}

interface Category {
  id: string;
  name: string;
  icon: string;
}

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  date: string;
  readTime: string;
  category: string;
}

// الأقسام - يمكن تحديثها لاحقاً
const categories: Category[] = [
  { id: 'all', name: 'الكل', icon: '📁' },
  { id: 'web', name: 'تطوير الويب', icon: '🌐' },
  { id: 'mobile', name: 'تطبيقات الموبايل', icon: '📱' },
  { id: 'design', name: 'التصميم', icon: '🎨' },
  { id: 'other', name: 'أخرى', icon: '✨' },
];

// بيانات تجريبية لمشاريع معرض الأعمال
const projects: Project[] = [
  {
    id: 1,
    title: 'متجر إلكتروني متكامل',
    description: 'منصة تجارة إلكترونية مع لوحة تحكم ونظام دفع إلكتروني',
    image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600',
    tags: ['React', 'Node.js', 'MongoDB'],
    link: '#',
    category: 'web',
  },
  {
    id: 2,
    title: 'تطبيق إدارة المهام',
    description: 'تطبيق موبايل لإدارة المهام اليومية مع مزامنة سحابية',
    image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=600',
    tags: ['React Native', 'Firebase'],
    link: '#',
    category: 'mobile',
  },
  {
    id: 3,
    title: 'هوية بصرية لشركة',
    description: 'تصميم شعار وهوية بصرية متكاملة لشركة ناشئة',
    image: 'https://images.unsplash.com/photo-1626785774573-4b799314348d?w=600',
    tags: ['Figma', 'Illustrator'],
    link: '#',
    category: 'design',
  },
  {
    id: 4,
    title: 'موقع تعريفي',
    description: 'موقع تعريفي لشركة خدمات استشارية',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600',
    tags: ['HTML', 'CSS', 'JavaScript'],
    link: '#',
    category: 'web',
  },
  {
    id: 5,
    title: 'تطبيق توصيل طلبات',
    description: 'تطبيق موبايل لتوصيل الطلبات مع تتبع مباشر',
    image: 'https://images.unsplash.com/photo-1556740758-90de374c12ad?w=600',
    tags: ['Flutter', 'Dart'],
    link: '#',
    category: 'mobile',
  },
  {
    id: 6,
    title: 'تصميم واجهة مستخدم',
    description: 'تصميم واجهة مستخدم لتطبيق مالي',
    image: 'https://images.unsplash.com/photo-1586717791821-3f44a5638d48?w=600',
    tags: ['UI/UX', 'Figma'],
    link: '#',
    category: 'design',
  },
];

// بيانات تجريبية للمدونة
const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: 'كيف تبدأ في تطوير الويب؟',
    excerpt: 'دليل شامل للمبتدئين في عالم تطوير الويب...',
    date: '2026-01-15',
    readTime: '5 دقائق',
    category: 'تطوير الويب',
  },
  {
    id: 2,
    title: 'أفضل ممارسات التصميم',
    excerpt: 'نصائح مهمة لتحسين تجربة المستخدم في تصميماتك...',
    date: '2026-01-10',
    readTime: '7 دقائق',
    category: 'التصميم',
  },
  {
    id: 3,
    title: 'مستقبل الذكاء الاصطناعي',
    excerpt: 'كيف سيغير الذكاء الاصطناعي صناعة البرمجيات...',
    date: '2026-01-05',
    readTime: '10 دقائق',
    category: 'تقنية',
  },
];

function App() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // تصفية المشاريع حسب القسم
  const filteredProjects = activeCategory === 'all'
    ? projects
    : projects.filter(p => p.category === activeCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50" dir="rtl">
      {/* الهيدر */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <span className="text-white text-xl">👨‍💻</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">مدونتي الشخصية</h1>
                <p className="text-sm text-gray-500">مطور ومصمم</p>
              </div>
            </div>

            {/* قائمة التنقل للسطح المكتبي */}
            <nav className="hidden md:flex gap-8">
              <a href="#home" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">الرئيسية</a>
              <a href="#portfolio" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">معرض الأعمال</a>
              <a href="#blog" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">المدونة</a>
              <a href="#contact" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">تواصل معي</a>
            </nav>

            {/* زر القائمة للموبايل */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {isMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>

          {/* قائمة الموبايل */}
          {isMenuOpen && (
            <nav className="md:hidden py-4 border-t">
              <div className="flex flex-col gap-4">
                <a href="#home" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">الرئيسية</a>
                <a href="#portfolio" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">معرض الأعمال</a>
                <a href="#blog" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">المدونة</a>
                <a href="#contact" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">تواصل معي</a>
              </div>
            </nav>
          )}
        </div>
      </header>

      {/* القسم الرئيسي */}
      <section id="home" className="py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="mb-8">
            <div className="w-32 h-32 mx-auto bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-xl">
              <span className="text-6xl">👋</span>
            </div>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            مرحباً، أنا <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">أحمد محمد</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            مطور ويب ومصمم شغوف بإنشاء تجارب رقمية مميزة. أهلاً بك في مدونتي الشخصية ومعرض أعمالي.
          </p>
          <div className="flex gap-4 justify-center">
            <a
              href="#portfolio"
              className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-medium hover:shadow-lg hover:scale-105 transition-all"
            >
              شاهد أعمالي
            </a>
            <a
              href="#contact"
              className="px-8 py-3 bg-white text-gray-700 rounded-xl font-medium border-2 border-gray-200 hover:border-blue-600 hover:text-blue-600 transition-all"
            >
              تواصل معي
            </a>
          </div>
        </div>
      </section>

      {/* معرض الأعمال */}
      <section id="portfolio" className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">معرض الأعمال</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              مجموعة من المشاريع التي عملت عليها في مجالات مختلفة
            </p>
          </div>

          {/* أزرار الفلترة */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-6 py-2 rounded-xl font-medium transition-all ${
                  activeCategory === category.id
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <span className="ml-2">{category.icon}</span>
                {category.name}
              </button>
            ))}
          </div>

          {/* شبكة المشاريع */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project) => (
              <div
                key={project.id}
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all hover:-translate-y-2 border border-gray-100"
              >
                <div className="h-48 overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{project.title}</h3>
                  <p className="text-gray-600 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <a
                    href={project.link}
                    className="inline-flex items-center gap-2 text-blue-600 font-medium hover:text-blue-700 transition-colors"
                  >
                    عرض المشروع
                    <svg className="w-4 h-4 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                    </svg>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* قسم المدونة */}
      <section id="blog" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">المدونة</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              مقالات وأفكار حول التطوير والتصميم والتقنية
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <article
                key={post.id}
                className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all border border-gray-100"
              >
                <div className="flex items-center gap-2 mb-4">
                  <span className="px-3 py-1 bg-purple-50 text-purple-600 rounded-full text-sm font-medium">
                    {post.category}
                  </span>
                  <span className="text-gray-400 text-sm">{post.readTime}</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3 hover:text-blue-600 cursor-pointer transition-colors">
                  {post.title}
                </h3>
                <p className="text-gray-600 mb-4">{post.excerpt}</p>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 text-sm">{post.date}</span>
                  <a href="#" className="text-blue-600 font-medium hover:text-blue-700 transition-colors">
                    اقرأ المزيد ←
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* قسم التواصل */}
      <section id="contact" className="py-20 px-4 bg-gradient-to-br from-blue-600 to-purple-700">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">هل لديك مشروع؟</h2>
          <p className="text-xl mb-8 opacity-90">
            دعنا نعمل معاً لتحويل فكرتك إلى واقع
          </p>
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <a
              href="mailto:email@example.com"
              className="px-6 py-3 bg-white/20 backdrop-blur rounded-xl font-medium hover:bg-white/30 transition-all flex items-center gap-2"
            >
              <span>📧</span> email@example.com
            </a>
            <a
              href="#"
              className="px-6 py-3 bg-white/20 backdrop-blur rounded-xl font-medium hover:bg-white/30 transition-all flex items-center gap-2"
            >
              <span>💼</span> LinkedIn
            </a>
            <a
              href="#"
              className="px-6 py-3 bg-white/20 backdrop-blur rounded-xl font-medium hover:bg-white/30 transition-all flex items-center gap-2"
            >
              <span>🐙</span> GitHub
            </a>
            <a
              href="#"
              className="px-6 py-3 bg-white/20 backdrop-blur rounded-xl font-medium hover:bg-white/30 transition-all flex items-center gap-2"
            >
              <span>🐦</span> Twitter
            </a>
          </div>
          <form className="max-w-md mx-auto bg-white/10 backdrop-blur rounded-2xl p-6">
            <div className="space-y-4">
              <input
                type="text"
                placeholder="الاسم"
                className="w-full px-4 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/50"
              />
              <input
                type="email"
                placeholder="البريد الإلكتروني"
                className="w-full px-4 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/50"
              />
              <textarea
                placeholder="رسالتك"
                rows={4}
                className="w-full px-4 py-3 rounded-xl bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/50 resize-none"
              ></textarea>
              <button
                type="submit"
                className="w-full px-6 py-3 bg-white text-blue-600 rounded-xl font-bold hover:bg-gray-100 transition-all"
              >
                إرسال الرسالة
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* الفوتر */}
      <footer className="bg-gray-900 text-white py-8 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-gray-400">
            © 2026 مدونتي الشخصية. جميع الحقوق محفوظة.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
